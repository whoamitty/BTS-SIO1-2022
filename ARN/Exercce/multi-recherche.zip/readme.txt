Multi-recherche---------------
Url     : http://codes-sources.commentcamarche.net/source/54858-multi-rechercheAuteur  : pokemon59Date    : 09/04/2014
Licence :
=========

Ce document intitul� � Multi-recherche � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Ce script permet de rechercher un texte sur un choix de 5 moteurs de recherche.

<br />Il suffit de choisir le moteur de recherche de son choix et d'&eacute;cri
re le texte souhait&eacute;, puis la recherche est envoy&eacute;e sur le moteur 
de recherche s&eacute;lectionn&eacute;.
