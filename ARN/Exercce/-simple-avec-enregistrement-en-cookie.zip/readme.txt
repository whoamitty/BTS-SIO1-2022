Bloc-note simple avec enregistrement en cookie----------------------------------------------
Url     : http://codes-sources.commentcamarche.net/source/54547-bloc-note-simple-avec-enregistrement-en-cookieAuteur  : pokemon59Date    : 10/08/2013
Licence :
=========

Ce document intitul� � Bloc-note simple avec enregistrement en cookie � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Un petit bloc-note avec enregistrement en cookie (basique).
<br />Il suffit de 
remplir un textarea pour l'enregistrer en cookie, pour pouvoir le lire plus tard
, le modifier et le supprimer.
<br />Tous cela en 5 pages.
<br /><a name='sour
ce-exemple'></a><h2> Source / Exemple : </h2>
<br /><pre class='code' data-mod
e='basic'>
Voir le Zip.
</pre>
<br /><a name='conclusion'></a><h2> Conclusion
 : </h2>
<br />Le desing est tr&egrave;s simple, et vous pouvez modifier cette
 source pour ajouter des champs tr&egrave;s facilement.
